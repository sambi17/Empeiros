<div id="foxmenucontainer">
  <div id="foxmenu">
    <ul>
      <li><a href="index.php" class="current"><span>Home</span></a></li>
      <li><a href="signup.php"><span>Register</span></a></li>
      <li><a href="signin.php"><span>Signin</span></a></li>
       <li><a href="postadd.php"><span>Post Content</span></a></li>

    </ul>
  </div>
</div>