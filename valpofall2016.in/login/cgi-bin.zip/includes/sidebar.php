<table border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td><div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Computers</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Furniture</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Appliances</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Cameras</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Health &amp; Products</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Jobs</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Handlet PC&rsquo;s</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Cables</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Memory</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Networking</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">PDAs</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">Scanners</a></div>
                    <div><img src="images/line_h2.gif" width="186" height="1" border="0" alt=""></div>
                    <div class="lmenu"><img src="images/ico2.gif" width="7" height="5" border="0" alt="" hspace="6"><a href="#" class="top11">All Products</a></div></td>
                </tr>
              </table>