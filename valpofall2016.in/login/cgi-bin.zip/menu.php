<html>
<style type="text/css">
body
{
	background-image:url(../images/bg4.jpg);
}
td { font-family:Tahoma, sans-serif; color:#444; font-size:0.85em;}
a { color:#FFF; text-decoration:none; font-family:"verdena"; font-size:0.82em; outline:none} 
a:hover { text-decoration:underline}
 h1 { padding:5px 10px; margin:0px; color:#006600; font-size:20px; color:#FFFFFF}
.pad { padding-left:15px;}
.pad a { color:#006699; text-decoration:none; font-weight:normal; font-size:13px; outline:none}
.pad a:hover { text-decoration:underline; color:#0000CC}
</style>
<body>
<table width="990" border="0" align="center" cellpadding="5" cellspacing="5">
  <tr>
    <td height="50" colspan="5" align="center" valign="top" bgcolor="#3e4247"><p style="font-size:30px; font-weight:bold; color:#fff; text-transform:uppercase;">Admin PANEL</p></td>
  </tr>
  <tr>
    <td width="217" height="50" align="center" valign="middle" bgcolor="#666633"><a href="home_content.php" class="one" style="font-family:Verdana, Geneva, sans-serif; font-size:10px; font-weight:bold;">HOME CONTENT</a></td>
    
    <td width="223" height="50" align="center" valign="middle" bgcolor="#669900"><a href="user.php" class="one" style="font-family:Verdana, Geneva, sans-serif; font-size:10px; font-weight:bold;">Signup Users</a></td>
    
    <td width="179" height="50" align="center" valign="middle" bgcolor="#669900"><a href="adposting.php" class="one" style="font-family:Verdana, Geneva, sans-serif; font-size:10px; font-weight:bold;">Ad Post Users</a></td>
   
    <td width="138" height="50" align="center" valign="middle" bgcolor="#669900"><a href="#" class="one" style="font-family:Verdana, Geneva, sans-serif; font-size:10px; font-weight:bold;">Help</a></td>
    
    <td width="153" height="50" align="center" valign="middle" bgcolor="#333"><a href="logout.php" class="one" style="font-family:Verdana, Geneva, sans-serif; font-size:10px; font-weight:bold;">LOGOUT</a></td>
  </tr>
</table>
</body>
</html>