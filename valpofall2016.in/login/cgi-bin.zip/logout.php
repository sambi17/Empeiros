<?php 
include("login.php");
$_SESSION['uname']='';
header("location:login.php");
?>