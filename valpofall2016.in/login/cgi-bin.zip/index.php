<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Test Application..</title>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" align="center" width="904" style="background-color:#06C">
	<tr>
		<td width="194" height="143" align="center" bgcolor="#FFFFFF">Logo Here</td>
		<td width="291" align="center" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="419" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="5" height="1" border="0" alt="">
		  <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
		    <tr>
		      <td align="left" valign="top"><table border="0" align="center" cellpadding="0" cellspacing="0">
		        <tr>
		          <td><img src="images/c1.gif" width="5" height="5" border="0" alt=""></td>
		          <td style="background: url(images/c_top.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
		          <td><img src="images/c2.gif" width="5" height="5" border="0" alt=""></td>
	            </tr>
		        <tr>
		          <td style="background: url(images/c_left.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
		          <td width="393" align="center"><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
		            <tr>
		              <td width="2%"><img src="images/spacer.gif" width="4" height="1" border="0" alt=""><a href="signup.php"><img src="images/signup1.png"></a></td>
		              <td width="40%" align="center"><a href="signin.php"><img src="images/signin1.png" alt=""></a></td>
		              <td width="10%">&nbsp;</td>
	                </tr>
	              </table></td>
		          <td style="background: url(images/c_right.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
	            </tr>
		        <tr>
		          <td><img src="images/c4.gif" width="5" height="5" border="0" alt=""></td>
		          <td style="background: url(images/c_bot.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
		          <td><img src="images/c3.gif" width="5" height="5" border="0" alt=""></td>
	            </tr>
	          </table></td>
	        </tr>
		    <tr>
		      <td align="left" valign="top">&nbsp;</td>
	        </tr>
        </table></td>
	</tr>
</table>




<table width="903" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr>
		<td align="left" valign="top" bgcolor="#6C7577">
        <?php
			include('includes/menu.php');
		?>
        
        </td>
	</tr>
</table>
<table width="908" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFFFFF"><table width="903" border="0" align="center" cellpadding="3" cellspacing="3" style="background-color:#fff;">
      <tr>
        <td colspan="5" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <td width="197" valign="top" bgcolor="#FFFFFF"><table border="0" cellpadding="0" cellspacing="0"  style="background: url(images/left_bg.gif)">
          <tr>
            <td><img src="images/left_left.gif" width="21" height="29" border="0" alt=""></td>
            <td><img src="images/spacer.gif" width="7" height="1" border="0" alt=""></td>
            <td width="170"><div class="lb">BROWSE BY CATEGORIES</div>
              <div class="lw">BROWSE BY CATEGORIES</div></td>
            <td><img src="images/left_right.gif" width="6" height="29" border="0" alt=""></td>
          </tr>
        </table>
          <table border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td style="background: url(images/c_left.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td width="194" align="center">
             	<?php
				 include('includes/sidebar.php');
				?>
              
              </td>
              <td style="background: url(images/c_right.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
            </tr>
            <tr>
              <td><img src="images/c4.gif" width="5" height="5" border="0" alt=""></td>
              <td style="background: url(images/c_bot.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td><img src="images/c3.gif" width="5" height="5" border="0" alt=""></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td><img src="images/c1.gif" width="5" height="5" border="0" alt=""></td>
              <td style="background: url(images/c_top.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td><img src="images/c2.gif" width="5" height="5" border="0" alt=""></td>
            </tr>
            <tr>
              <td style="background: url(images/c_left.gif)">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td style="background: url(images/c_right.gif)">&nbsp;</td>
            </tr>
            <tr>
              <td style="background: url(images/c_left.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td width="194" align="center"><a href="#"><img src="images/add4.jpg" border="0" alt=""><img src="images/add4.jpg" border="0" alt=""></a></td>
              <td style="background: url(images/c_right.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
            </tr>
            <tr>
              <td><img src="images/c4.gif" width="5" height="5" border="0" alt=""></td>
              <td style="background: url(images/c_bot.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td><img src="images/c3.gif" width="5" height="5" border="0" alt=""></td>
            </tr>
          </table></td>
        <td width="4"><img src="images/spacer.gif" width="4" height="1" border="0" alt=""></td>
        <td width="207" valign="top"><table border="0" cellpadding="0" cellspacing="0"  style="background: url(images/left_bg.gif)">
          <tr>
            <td><img src="images/left_left.gif" width="21" height="29" border="0" alt=""></td>
            <td><img src="images/spacer.gif" width="7" height="1" border="0" alt=""></td>
            <td width="170"><div class="lb">BROWSE BY CATEGORIES</div>
              <div class="lw">BROWSE BY CATEGORIES</div></td>
            <td><img src="images/left_right.gif" width="6" height="29" border="0" alt=""></td>
          </tr>
        </table>
          <table border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td style="background: url(images/c_left.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td width="194" align="center"><table border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="background: url(images/c_left.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
                  <td width="194" align="center" bgcolor="#FFFFFF">
                  <?php
				  include('includes/sidebar1.php');
				  ?>
                  
                  </td>
                  <td style="background: url(images/c_right.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
                </tr>
                <tr>
                  <td><img src="images/c4.gif" width="5" height="5" border="0" alt=""></td>
                  <td style="background: url(images/c_bot.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
                  <td><img src="images/c3.gif" width="5" height="5" border="0" alt=""></td>
                </tr>
              </table></td>
              <td style="background: url(images/c_right.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
            </tr>
            <tr>
              <td><img src="images/c4.gif" width="5" height="5" border="0" alt=""></td>
              <td style="background: url(images/c_bot.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td><img src="images/c3.gif" width="5" height="5" border="0" alt=""></td>
            </tr>
          </table>
          <table border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td><img src="images/c1.gif" width="5" height="5" border="0" alt=""></td>
              <td style="background: url(images/c_top.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td><img src="images/c2.gif" width="5" height="5" border="0" alt=""></td>
            </tr>
            <tr>
              <td style="background: url(images/c_left.gif)">&nbsp;</td>
              <td align="center" bgcolor="#FFFFFD">&nbsp;</td>
              <td style="background: url(images/c_right.gif)">&nbsp;</td>
            </tr>
            <tr>
              <td style="background: url(images/c_left.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td width="194" align="center" bgcolor="#FFFFFD"><a href="#"><img src="images/so_img.jpg" width="116" height="112" border="0" alt=""></a>
                <div style="padding: 9px 0 4px 0"></div>
                </td>
              <td style="background: url(images/c_right.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
            </tr>
            <tr>
              <td><img src="images/c4.gif" width="5" height="5" border="0" alt=""></td>
              <td style="background: url(images/c_bot.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
              <td><img src="images/c3.gif" width="5" height="5" border="0" alt=""></td>
            </tr>
          </table></td>
        <td width="1" valign="top" bgcolor="#FFFDFE">&nbsp;</td>
        <td width="449" valign="top"><table border="0" cellpadding="0" cellspacing="0"  style="background: url(images/left_bg.gif)">
            <tr>
              <td><img src="images/left_left.gif" width="21" height="29" border="0" alt=""></td>
              <td><img src="images/spacer.gif" width="7" height="1" border="0" alt=""></td>
              <td width="404"><div class="lb">FEATURED PRODUCTS</div>
                <div class="lw">FEATURED PRODUCTS</div></td>
              <td><img src="images/left_right.gif" width="6" height="29" border="0" alt=""></td>
            </tr>
          </table>
          <table width="98%" border="0" align="left" cellpadding="0" cellspacing="0">
            <tr>
              <td align="left" valign="top"><table border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="background: url(images/c_left.gif)">&nbsp;</td>
                  <td align="center" bgcolor="#FFFFFD"><table width="98%" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td height="126"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="92" align="center"><a href="#"><img src="images/img1.jpg" width="79" height="66" border="0" alt=""></a></td>
                          <td width="311"><div class="item_name">Product 1</div>
                            <div class="item_desc">
                              <p style="text-align:justify; font-weight:normal;">
							  
							 
<?php
mysql_connect("localhost", "root", "") or
    die("Could not connect: " . mysql_error());
mysql_select_db("netra");

$result = mysql_query("HomeContent.php");
?>
                            </div>
                            <div style="padding-bottom: 5px"></div></td>
                        </tr>
                      </table></td>
                    </tr>
                  </table></td>
                  <td style="background: url(images/c_right.gif)">&nbsp;</td>
                </tr>
                <tr>
                  <td style="background: url(images/c_left.gif)">&nbsp;</td>
                  <td align="center" bgcolor="#FFFFFD"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="92" align="center"><a href="#"><img src="images/img1.jpg" width="79" height="66" border="0" alt=""></a></td>
                      <td width="311"><div class="item_name">Product 2</div>
                        <div class="item_desc">
                          <p style="text-align:justify; font-weight:normal;">Requirements of computer operators (Hyderabad) [This ad has picture(s)]  - Business ~@ Business Opportunities VNS Pvt. Ltd. providing the services to the customer in the era of Consulting services in corporate. having a pioneer from last 03 years in services of Client. For more information contact on the following number: 9812312365, 9812312365. PO...</p>
                        </div>
                        <div style="padding-bottom: 5px"></div></td>
                    </tr>
                  </table></td>
                  <td style="background: url(images/c_right.gif)">&nbsp;</td>
                </tr>
                <tr>
                  <td style="background: url(images/c_left.gif)">&nbsp;</td>
                  <td align="left" bgcolor="#FFFFFD"><div class="item_name">Categories</div></td>
                  <td style="background: url(images/c_right.gif)">&nbsp;</td>
                </tr>
                <tr>
                  <td style="background: url(images/c_left.gif)">&nbsp;</td>
                  <td align="center" bgcolor="#FFFFFD"><table border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td><table border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="86" align="center"><a href="#"><img src="images/img1.jpg" width="79" height="66" border="0" alt=""></a></td>
                          <td width="120"><div class="item_name">Product 1</div>
                            <div class="item_desc" style="font-weight:normal;">Requirements of computer operators (Hyderabad) [This ad has picture(s)] </div>
                            <div style="padding-bottom: 5px"></div></td>
                        </tr>
                      </table></td>
                      <td style="background: url(images/bg_ver.gif) repeat-y center" height="126"><img src="images/spacer.gif" width="14" height="1" border="0" alt=""></td>
                      <td><table border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="86" align="center"><a href="#"><img src="images/img2.jpg" width="72" height="56" border="0" alt=""></a></td>
                          <td width="120"><div class="item_name">Product 2</div>
                            <div class="item_desc" style="font-weight:normal;">Requirements of computer operators (Hyderabad) [This ad has picture(s)] </div>                            <div style="padding-bottom: 5px"></div></td>
                        </tr>
                      </table></td>
                    </tr>
                  </table></td>
                  <td style="background: url(images/c_right.gif)">&nbsp;</td>
                </tr>
                <tr>
                  <td style="background: url(images/c_left.gif)">&nbsp;</td>
                  <td align="center" bgcolor="#FFFFFD"><table border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td><table border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="86" align="center"><a href="#"><img src="images/img1.jpg" width="79" height="66" border="0" alt=""></a></td>
                          <td width="120"><div class="item_name">Product 3</div>
                            <div class="item_desc" style="font-weight:normal;">Requirements of computer operators (Hyderabad) [This ad has picture(s)] </div>                            <div style="padding-bottom: 5px"></div></td>
                        </tr>
                      </table></td>
                      <td style="background: url(images/bg_ver.gif) repeat-y center" height="126"><img src="images/spacer.gif" width="14" height="1" border="0" alt=""></td>
                      <td><table border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="86" align="center"><a href="#"><img src="images/img2.jpg" width="72" height="56" border="0" alt=""></a></td>
                          <td width="120"><div class="item_name">Product 4</div>
                            <div class="item_desc" style="font-weight:normal;">Requirements of computer operators (Hyderabad) [This ad has picture(s)] </div>                            <div style="padding-bottom: 5px"></div></td>
                        </tr>
                      </table></td>
                    </tr>
                  </table></td>
                  <td style="background: url(images/c_right.gif)">&nbsp;</td>
                </tr>
                <tr>
                  <td style="background: url(images/c_left.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
                  <td width="428" align="center" bgcolor="#FFFFFD"><table border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td><table border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="86" align="center"><a href="#"><img src="images/img1.jpg" width="79" height="66" border="0" alt=""></a></td>
                          <td width="120"><div class="item_name">Product 5</div>
                            <div class="item_desc" style="font-weight:normal;">Requirements of computer operators (Hyderabad) [This ad has picture(s)] </div>                            <div style="padding-bottom: 5px"></div></td>
                        </tr>
                      </table></td>
                      <td style="background: url(images/bg_ver.gif) repeat-y center" height="126"><img src="images/spacer.gif" width="14" height="1" border="0" alt=""></td>
                      <td><table border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="86" align="center"><a href="#"><img src="images/img2.jpg" width="72" height="56" border="0" alt=""></a></td>
                          <td width="120"><div class="item_name">Product 6</div>
                            <div class="item_desc" style="font-weight:normal;">Requirements of computer operators (Hyderabad) [This ad has picture(s)] </div>                            <div style="padding-bottom: 5px"></div></td>
                        </tr>
                      </table></td>
                    </tr>
                  </table></td>
                  <td style="background: url(images/c_right.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
                </tr>
                <tr>
                  <td><img src="images/c4.gif" width="5" height="5" border="0" alt=""></td>
                  <td style="background: url(images/c_bot.gif)"><img src="images/spacer.gif" width="1" height="1" border="0" alt=""></td>
                  <td><img src="images/c3.gif" width="5" height="5" border="0" alt=""></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td align="left" valign="top">&nbsp;</td>
            </tr>
            
            <tr>
              <td align="left" valign="top">&nbsp;</td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="60" align="left" valign="top" bgcolor="#FF0000"><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="63%">
        
        <?php
			include('includes/footer.php');
		?>
        
        </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="10" align="left" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
</body>
</html>